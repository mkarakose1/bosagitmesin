import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: ' ',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2E7D32),
          primary: const Color(0xFF2E7D32),
          secondary: const Color(0xFF81C784),
        ),
        useMaterial3: true,
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: const LandingPage(),
    );
  }
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  final _formKey = GlobalKey<FormState>();
  String _selectedDistrict = 'Kadıköy';
  final _emailController = TextEditingController();

  final List<String> _districts = [
    'Adalar',
    'Arnavutköy',
    'Ataşehir',
    'Avcılar',
    'Bağcılar',
    'Bahçelievler',
    'Bakırköy',
    'Başakşehir',
    'Bayrampaşa',
    'Beşiktaş',
    'Beykoz',
    'Beylikdüzü',
    'Beyoğlu',
    'Büyükçekmece',
    'Çatalca',
    'Çekmeköy',
    'Esenler',
    'Esenyurt',
    'Eyüpsultan',
    'Fatih',
    'Gaziosmanpaşa',
    'Güngören',
    'Kadıköy',
    'Kağıthane',
    'Kartal',
    'Küçükçekmece',
    'Maltepe',
    'Pendik',
    'Sancaktepe',
    'Sarıyer',
    'Şile',
    'Silivri',
    'Şişli',
    'Sultanbeyli',
    'Sultangazi',
    'Tuzla',
    'Ümraniye',
    'Üsküdar',
    'Zeytinburnu',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.only(top: 32),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.grey.shade300,
                    Colors.grey.shade100,
                  ],
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Image.asset(
                      'assets/images/logo.png',
                      width: 220,
                      height: 220,
                    ),
                  ),
                  Text(
                    'Boşa Gitmesin',
                    style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                          color: Colors.black87,
                          fontWeight: FontWeight.bold,
                        ),
                  )
                      .animate()
                      .fadeIn(delay: 200.ms)
                      .slideY(begin: 0.3, end: 0),
                  const SizedBox(height: 16),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Text(
                      'Restoranların kapanış saatinde kalan lezzetli yemekleri uygun fiyatlarla sizlere ulaştırıyoruz.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Colors.black87,
                          ),
                    ),
                  )
                      .animate()
                      .fadeIn(delay: 400.ms)
                      .slideY(begin: 0.3, end: 0),
                  const SizedBox(height: 24),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      children: [
                        _buildFactCard(
                          icon: Icons.delete_outline,
                          title: '23 Milyon Ton',
                          description: 'Türkiye\'de her yıl yaklaşık 23 milyon ton gıda israf ediliyor. Bu, üretilen gıdanın yaklaşık %35\'i sofraya ulaşamadan kayboluyor.',
                        ),
                        const SizedBox(height: 12),
                        _buildFactCard(
                          icon: Icons.bakery_dining,
                          title: '12 Milyon Ekmek',
                          description: 'Ülkede her gün yaklaşık 12 milyon ekmek çöpe atılıyor. Bu, yılda 4 milyar 380 milyon ekmeğe denk geliyor.',
                        ),
                        const SizedBox(height: 12),
                        _buildFactCard(
                          icon: Icons.trending_up,
                          title: '%86.2 Enflasyon',
                          description: 'Dar gelirli vatandaşların hissettiği gıda enflasyonu %86.2\'ye kadar çıkıyor. Resmi enflasyon %48.57 iken...',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nasıl Çalışır?',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                  )
                      .animate()
                      .fadeIn()
                      .slideX(begin: -0.3, end: 0),
                  const SizedBox(height: 24),
                  _buildHowItWorksCard(
                    '1',
                    'Restoranlar Kapanışa Yakın',
                    'Restoranlar kapanış saatine yakın, gün sonunda kalan yemekleri uygulamamıza ekler.',
                    Icons.store,
                  )
                      .animate()
                      .fadeIn(delay: 200.ms)
                      .slideX(begin: -0.3, end: 0),
                  const SizedBox(height: 16),
                  _buildHowItWorksCard(
                    '2',
                    'Siz Seçin',
                    'Size en yakın restoranlardan, kalan yemekler arasından seçim yapın.',
                    Icons.touch_app,
                  )
                      .animate()
                      .fadeIn(delay: 400.ms)
                      .slideX(begin: -0.3, end: 0),
                  const SizedBox(height: 16),
                  _buildHowItWorksCard(
                    '3',
                    'Uygun Fiyatla Alın',
                    'Normal fiyatın %50-70 daha uygun fiyatlarla lezzetli yemekleri güvenle alın.',
                    Icons.shopping_bag,
                  )
                      .animate()
                      .fadeIn(delay: 600.ms)
                      .slideX(begin: -0.3, end: 0),
                  const SizedBox(height: 32),
                  Text(
                    'Siz de Katılın',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                  )
                      .animate()
                      .fadeIn(delay: 800.ms)
                      .slideX(begin: -0.3, end: 0),
                  const SizedBox(height: 16),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        DropdownButtonFormField<String>(
                          value: _selectedDistrict,
                          decoration: const InputDecoration(
                            labelText: 'İlçe',
                            border: OutlineInputBorder(),
                          ),
                          items: _districts
                              .map((district) => DropdownMenuItem(
                                    value: district,
                                    child: Text(district),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedDistrict = value!;
                            });
                          },
                        )
                            .animate()
                            .fadeIn(delay: 1000.ms)
                            .slideY(begin: 0.3, end: 0),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _emailController,
                          decoration: const InputDecoration(
                            labelText: 'E-posta',
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Lütfen e-posta adresinizi girin';
                            }
                            if (!value.contains('@')) {
                              return 'Geçerli bir e-posta adresi girin';
                            }
                            return null;
                          },
                        )
                            .animate()
                            .fadeIn(delay: 1200.ms)
                            .slideY(begin: 0.3, end: 0),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                submitToSheets(_emailController.text, _selectedDistrict);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Talebiniz alındı!'),
                                  ),
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).colorScheme.primary,
                              foregroundColor: Colors.white,
                            ),
                            child: const Text(
                              'Bana Haber Ver',
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                        )
                            .animate()
                            .fadeIn(delay: 1400.ms)
                            .slideY(begin: 0.3, end: 0),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHowItWorksCard(String step, String title, String description, IconData icon) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  step,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        icon,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        title,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFactCard({required IconData icon, required String title, required String description}) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 40, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 16),
            Expanded(
        child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                  ),
                  const SizedBox(height: 4),
            Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

const String sheetsUrl = 'https://api.sheetbest.com/sheets/20a3cbce-edae-485c-a25b-eb66c2e1ddaa';

Future<void> submitToSheets(String email, String district) async {
  final response = await http.post(
    Uri.parse(sheetsUrl),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({'email': email, 'district': district}),
  );
  if (response.statusCode != 200 && response.statusCode != 201) {
    throw Exception('Failed to submit: ${response.body}');
  }
}
